Java 11: No
Java 12: Yes


This file contains 4 files. 
1. wordProcessor.java which has all of the code needed to run the program
2. screenshots of program running
3. myFile.txt is the output file
4. README.txt 

To run the program open WordProcessor.java in an IDE, build and run. Enter a username and password if you like
the first card, after you click ok you will be taken to a second
card. After you type in the text area of the second card, use the menu to 
click save and the text you wrote will be saved to myfile.txt. 
You can click exit and the application will shut down.